package com.example.datapassing

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val tv = findViewById<TextView>(R.id.tv)
        val name = intent.getStringExtra("NAME")
        val regd = intent.getStringExtra("REGD_NUM")
        val mobi = intent.getStringExtra("MOBI_NUM")
        tv.text = "Received Data is: Name is $name \n Registration Num is $regd \n Mobil Num $mobi"
    }
}