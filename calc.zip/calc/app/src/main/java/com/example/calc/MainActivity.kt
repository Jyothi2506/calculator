package com.example.datapassing

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import com.example.calc.R

class MainActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val et1 = findViewById<EditText>(R.id.et1)
        val et2 = findViewById<EditText>(R.id.et2)
        val et3 = findViewById<EditText>(R.id.et3)
        val btn = findViewById<Button>(R.id.btn)

        btn.setOnClickListener {
            val name = et1.text.toString()
            val regd = et2.text.toString()
            val mobi = et3.text.toString()

            val intent = Intent(this, SecondActivity::class.java)

            intent.putExtra("NAME", name)
            intent.putExtra("REGD_NUM", regd)
            intent.putExtra("MOBI_NUM", mobi)
            startActivity(intent)
        }

    }

}

private fun ERROR.putExtra(string: String, string: String) {
    TODO("Not yet implemented")
}

private fun AppCompatActivity.onCreate(bundle: Bundle?) {


}
